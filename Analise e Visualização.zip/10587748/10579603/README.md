---
author: "Maria Izabel"
format: html
editor: visual
Copyright: "Maria Izabel de Almeida Leite"
  toc: true 
warning: false 
message: false
editor_options: moderno
  markdown: 
    wrap: 72
---

# FIP-606-Analise-e-visualiza-o-de-dados-em-Fitopatologia

# 
